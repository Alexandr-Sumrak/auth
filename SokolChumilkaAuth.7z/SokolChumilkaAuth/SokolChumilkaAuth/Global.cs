﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data;
using MySql.Data.MySqlClient;

namespace SokolChumilkaAuth
{
    class Global
    {


        string strconnect = "host=185.22.233.248;Database=library;User=library;Password=7Z0s0G2b";
        public int auth(string login, string pass)
        {
            int answer = 0;
            using (MySqlConnection connection = new MySqlConnection(strconnect))
            {
                connection.Open();
                MySqlCommand cmd = new MySqlCommand("SELECT * FROM users WHERE login = @login AND password = @password", connection);
                MySqlParameter loginParam = new MySqlParameter("@login", login);
                MySqlParameter passParam = new MySqlParameter("@password", pass);
                cmd.Parameters.Add(loginParam);
                cmd.Parameters.Add(passParam);
                answer = Convert.ToInt32(cmd.ExecuteScalar());
            }
            return answer;
        }

        public User SelectUse(int id)
        {
            User users = new User();
            using (MySqlConnection connection = new MySqlConnection(strconnect))
            {
                connection.Open();
                MySqlCommand cmd = new MySqlCommand("SELECT * FROM users WHERE id=@id", connection);
                MySqlParameter idParam = new MySqlParameter("@id", id);
                cmd.Parameters.Add(idParam);
                MySqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    users.role = reader.GetValue(10).ToString();
 
                }
            }
            return users;
        }
    }

   
}
